// ClearGem v1.0.8 — Content Script (ISOLATED world)
// Relays fetch requests from MAIN world to background service worker.
'use strict';

(function () {
    // MAIN → ISOLATED → Background
    window.addEventListener('message', (e) => {
        if (e.source !== window || !e.data || e.data.type !== 'cleargem-fetch-request') return;

        const { id, url } = e.data;
        console.log('[ClearGem Relay] Request:', url.substring(0, 80));

        chrome.runtime.sendMessage({ type: 'cleargem-fetch', url }, (resp) => {
            if (chrome.runtime.lastError) {
                console.error('[ClearGem Relay] Error:', chrome.runtime.lastError.message);
                window.postMessage({
                    type: 'cleargem-fetch-response',
                    id,
                    ok: false,
                    error: chrome.runtime.lastError.message
                }, '*');
                return;
            }
            window.postMessage({
                type: 'cleargem-fetch-response',
                id,
                ok: resp?.ok || false,
                dataUrl: resp?.dataUrl,
                error: resp?.error
            }, '*');
        });
    });

    console.log('[ClearGem Relay] v1.0.8 content relay loaded');
})();
